#include <stdio.h>
#include <Windows.h>

DWORD WINAPI ExThread1(LPVOID lparam) {
	while (1)
	{
		printf("A\n");
	}
	return 0;
}

DWORD WINAPI ExThread2(LPVOID lparam) {
	
	printf("B\n");
	return 0;
}

int main() {
	char inputch[512];
	HANDLE hThread;
	DWORD lpExitCode;

	hThread = CreateThread(NULL, 0, ExThread1, 0, 0, NULL);
	hThread = CreateThread(NULL, 0, ExThread2, 0, 0, NULL);

	while (1)
	{
		GetExitCodeThread(hThread, &lpExitCode);

		if (lpExitCode == STILL_ACTIVE) {
			printf("Still Active\n");
		}
		else {
			break;
		}
	}

	return 0;
}